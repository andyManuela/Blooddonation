const pool = require("../../config/database");

module.exports={
    create: (data, callBack) =>{
        pool.query(
            'insert into receiver(name,email,password,phonenumber,bloodgroup,age,address) values(?,?,?,?,?,?,?)',
            [
                data.Fname,
                data.email,
                data.password,
                data.phonenumber,
                data.bloodgroup,
                data.age,
                data.address
            ],
            (error, results, fields)=>{
                if (error){
                    return callBack(error)
                }
                return callBack(null, results);
            }
        );
    },
    getUsers: callBack=>{
        pool.query(
        'select receiver.name, receiver.phonenumber, receiver.bloodgroup, bloodrequest.donationdate,bloodrequest.address,bloodrequest.bloodgroup, bloodrequest.content from receiver,bloodrequest where bloodrequest.receiver_id=receiver.receiver_id',
        [],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
    getUserByUserId: callBack=>{
        pool.query(
        'select * from donor',
        [],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
    updateUser:(data, callBack)=>{
        pool.query(
            'update receiver set name=?, email=?, phonenumber=? where receiver_id=?',
            [
                data.Fname,
                data.email,
                data.phonenumber,
                data.id
            ],
            (error, results, fields)=>{
                if(error){
                    return callBack(error);
                }
                return callBack(null, results[0]);
            }
        )
    },
    deleteUser:(data, callBack)=>{
        pool.query(
            'delete from notification where notification_id = ?',
            [data.id],
            (error, results, fields)=>{
                if(error){
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    },
    getUserByUserEmail:(email, callBack)=>{
        pool.query(
            'select * from receiver where email = ?',
            [email],
            (error, results, fields)=>{
                if(error){
                    callBack(error);
                }
                return callBack(null, results[0]);
            }
        )
    },
    getUserRequests: callBack=>{
        pool.query(
        'select * from receiver',
        [],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
    createRequest: (data, callBack) =>{
        pool.query(
            'insert into bloodrequest(donationdate,bloodgroup,address,content,receiver_id) values(?,?,?,?,?)',
            [
                data.donationdate,
                data.bloodgroup,
                data.address,
                data.content,
                data.receiver_id
            ],
            (error, results, fields)=>{
                if (error){
                    return callBack(error)
                }
                return callBack(null, results);
            }
        );
    },
    createDonor: (data, callBack) =>{
        pool.query(
            'insert into donor(name,email,phonenumber,bloodgroup,age,address, longitude, latitude) values(?,?,?,?,?,?,?,?)',
            [
                data.Fname,
                data.email,
                data.phonenumber,
                data.bloodgroup,
                data.age,
                data.address,
                data.longitude,
                data.latitude
            ],
            (error, results, fields)=>{
                if (error){
                    return callBack(error)
                }
                return callBack(null, results);
            }
        );
    },
    getDonors: (id, callBack)=>{
        pool.query(
        'select * from receiver where receiver_id=?',
        [id],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results[0]);
            }
      );
    },
    getRequestById: (id, callBack)=>{
        pool.query(
        'select * from bloodrequest where receiver_id=?',
        [id],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
    getNotification: (id, callBack)=>{
        pool.query(
            'select notification.notification_id, receiver.name, bloodrequest.address,bloodrequest.bloodgroup from notification,receiver,bloodrequest where notification.receiver_id=receiver.receiver_id AND notification.request_id=bloodrequest.request_id AND notification.receiver_id != ?',
        [id],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
    getLastRequest: callBack=>{
        pool.query(
        'select receiver.name, receiver.phonenumber, receiver.bloodgroup, bloodrequest.request_id, bloodrequest.donationdate,bloodrequest.address,bloodrequest.bloodgroup from receiver,bloodrequest where bloodrequest.receiver_id=receiver.receiver_id ORDER BY bloodrequest.request_id DESC LIMIT 3',
        [],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
    deleteRequest:(data, callBack)=>{
        pool.query(
            'delete from bloodrequest where request_id = ?',
            [data.id],
            (error, results, fields)=>{
                if(error){
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    },
}