const {
    createUser, 
    getUserByUserId, 
    getUsers, 
    updateUser, 
    deleteUser,
    login,
    getUserRequests,
    createRequest,
    createDonor,
    getDonors,
    getRequestById,
    getNotification,
    getLastRequest,
    deleteRequest
} = require("./user.controller");
const router = require("express").Router();

router.post("/",createUser);
router.post("/donor",createDonor);
router.post("/login", login);
router.post("/create",createRequest);
router.get("/", getUsers);
router.get("/request/:id", getRequestById);
router.get("/request2/:id", getNotification);
router.get("/donor", getUserByUserId);
router.get("/:id", getDonors);
router.get("/req", getUserRequests);
router.get("/last", getLastRequest);
router.patch("/", updateUser);
router.delete("/", deleteUser);
router.delete("/request", deleteRequest);

module.exports = router;