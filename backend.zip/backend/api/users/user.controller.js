const {
    create,
    getUserByUserId,
    getUsers,
    updateUser,
    deleteUser,
    getUserByUserEmail,
    getUserRequests,
    createRequest,
    createDonor,
    getDonors,
    getRequestById,
    getNotification,
    getLastRequest,
    deleteRequest
} = require("./user.service");

const { genSaltSync, hashSync, compareSync } = require("bcrypt");

module.exports = {
    createUser: (req,res)=>{
        const body = req.body;
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);
        create(body, (err, results)=>{
            if (err){
                console.log(err);
                return res.status(500).json({
                    success: 0,
                    message:"Database connection error"
                });
            }
            return res.status(200).json({
                success:1,
                data:body
            });
        });

    },
    getUserByUserId:(req,res)=>{
        getUserByUserId((err,results)=>{
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data:results
            });
        });
    },
    getUsers:(req,res)=>{
        getUsers((err,results)=>{
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    updateUser:(req,res)=>{
        const body = req.body;
        updateUser(body,(err, results)=>{
          if(err){
            console.log(err);
            return;
          }
          return res.json({
            success:1,
            message:"update successfully"
          });
        });
    },
    deleteUser:(req, res)=>{
        const data = req.body;
        deleteUser(data,(err,results)=>{
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                returnres.json({
                    success: 0,
                    message:"Record not found"
                });
            }
            return res.json({
                success: 1,
                message:"notification deleted successfully"
            });
        });
    },
    login:(req, res)=>{
        const body = req.body;
        getUserByUserEmail(body.email, (err, results)=>{
            if(err){
                console.log(err);
            }
            if(!results){
                return res.json({
                    success: 0,
                    data:"No record found"
                });
            }
            const salt = genSaltSync(10);
            //body.password = hashSync(body.password, salt);
            const result = compareSync(body.password,results.password);
            if (result){
                results.password = undefined;
                return res.json({
                    success: 1,
                    data: results
                });
            }else{
                return res.json({
                    success: 0,
                    data: "invalid email and password"
                });
            }
        });
    },
    getUserRequests:(req,res)=>{
        getUserRequests((err,results)=>{
            if(err){
                console.log(err);
                return;
            }else{
                 
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    createRequest: (req,res)=>{
        const body = req.body;
        createRequest(body, (err, results)=>{
            if (err){
                console.log(err);
                return res.status(500).json({
                    success: 0,
                    message:"Database connection error"
                });
            }
            return res.status(200).json({
                success:1,
                data:body
            });
        });

    },
    createDonor: (req,res)=>{
        const body = req.body;
        createDonor(body, (err, results)=>{
            if (err){
                console.log(err);
                return res.status(500).json({
                    success: 0,
                    message:"Database connection error"
                });
            }
            return res.status(200).json({
                success:1,
                data:body
            });
        });

    },
    getDonors:(req, res)=>{
        const id=req.params.id;
        getDonors(id, (err, results)=>{
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    success:0,
                    message:"record not found"
                });
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    getRequestById:(req, res)=>{
        const id=req.params.id;
        getRequestById(id, (err, results)=>{
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    getNotification:(req, res)=>{
        const id=req.params.id;
        getNotification(id, (err, results)=>{
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    success:0,
                    message:"record not found"
                });
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    getLastRequest:(req,res)=>{
        getLastRequest((err,results)=>{
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    deleteRequest:(req, res)=>{
        const data = req.body;
        deleteRequest(data,(err,results)=>{
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                returnres.json({
                    success: 0,
                    message:"Record not found"
                });
            }
            return res.json({
                success: 1,
                message:"notification deleted successfully"
            });
        });
    },
}