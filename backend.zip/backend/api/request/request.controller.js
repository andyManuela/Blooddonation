const {
    getUserReal
} = require("./request.service");


module.exports = {
    getUsers:(req,res)=>{
        getUserReal((err,results)=>{
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data: "hello"
            });
        });
    },
}