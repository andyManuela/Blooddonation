const pool = require("../../config/database");

module.exports={
    getUserReal: callBack=>{
        pool.query(
        'select name, email from receiver',
        [],
            (error, results, fields)=>{
                if(error){
                   return callBack(error);
                }
                return callBack(null, results);
            }
      );
    },
}